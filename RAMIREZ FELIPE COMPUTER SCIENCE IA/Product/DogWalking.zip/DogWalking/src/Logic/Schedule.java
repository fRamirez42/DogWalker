/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Logic;

/**
 *
 * @author Ramfel22
 */
public class Schedule {

    private String location;
    
    private String dogName;

    private String monday;

    private String tuesday;

    private String wednesday;

    private String thursday;

    private String friday;

    private String saturday;

    private String sunday;

    public Schedule(String l, String dn, String m, String t, String w, String th, String f, String s, String su) {

        location = l;

        dogName = dn;
        
        monday = m;

        tuesday = t;

        wednesday = w;

        thursday = th;

        friday = f;

        saturday = s;

        sunday = su;

    }

    public String getLocation() {

        return location;

    }

    public void setLocation(String l) {

        location = l;

    }

    public String getMonday() {

        return monday;

    }

    public void setMonday(String m) {

        monday = m;

    }

    public String getDogName() {

        return dogName;

    }

    public void setDogName(String dn) {

        dogName = dn;

    }

    public String getTuesday() {

        return tuesday;

    }

    public void setTuesday(String t) {

        tuesday = t;

    }

    public String getWednesday() {

        return wednesday;

    }

    public void setWednesay(String w) {

        wednesday = w;

    }

    public String getThursday() {

        return thursday;

    }

    public void setThursday(String th) {

        thursday = th;

    }

    public String getFriday() {

        return friday;

    }

    public void setFriday(String f) {

        friday = f;

    }

    public String getSaturday() {

        return saturday;

    }

    public void setSaturday(String s) {

        saturday = s;

    }

    public String getSunday() {

        return sunday;

    }

    public void setSunday(String su) {

        sunday = su;

    }
}
