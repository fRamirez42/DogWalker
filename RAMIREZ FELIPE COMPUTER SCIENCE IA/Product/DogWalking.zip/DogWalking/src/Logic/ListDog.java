/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Logic;

/**
 *
 * @author Ramfel22
 */
public class ListDog {

    NodeDog first;

    public ListDog() {

        first = null;

    }

    public NodeDog getFirst() {

        return first;

    }

    public boolean addNode(Dog d) {
        NodeDog nn = new NodeDog(d);

        if (first == null) {

            first = nn;

            return true;

        } else {

            NodeDog aux = first;

            while (aux.getNext() != null) {

                aux = aux.getNext();

            }

            aux.setNext(nn);

            return true;

        }
    }

    public boolean deleteNode(String id) {

        if (first == null) {

            return false;

        } else if (first.getData().getId().equals(id)) {

            first = first.getNext();

            return true;

        } else {

            NodeDog aux = first;

            while (aux.getNext() != null) {

                if (aux.getNext().getData().getId().equals(id)) {

                    aux.setNext(aux.getNext().getNext());

                    return true;

                } else {

                    aux = aux.getNext();

                }

            }

        }

        return false;

    }

    public boolean modifyNode(Dog d) {

        NodeDog aux = first;

        while (aux != null) {

            if (aux.getData().getId().equals(d.getId())) {

                aux.setData(d);

                return true;

            } else {

                aux = aux.getNext();

            }

        }

        return false;

    }

    public Dog searchNode(String id) {

        NodeDog aux = first;

        while (aux != null) {

            if (aux.getData().getId().equals(id)) {

                return aux.getData();

            } else {

                aux = aux.getNext();

            }

        }

        return null;

    }

    public boolean searchDuplicate(String id) {

        NodeDog aux = first;

        while (aux != null) {

            if (aux.getData().getId().equals(id)) {

                return true;

            } else {

                aux = aux.getNext();

            }

        }

        return false;

    }

    public ListDog searchDog(String breed) {

        NodeDog aux = first;
        ListDog ret = new ListDog();
        while (aux != null) {

            if (aux.getData().getBreed().equals(breed)) {
                Dog d = aux.getData();
                ret.addNode(d);

            }

            aux = aux.getNext();

        }

        return ret;

    }

    public String searchDname(String id) {

        NodeDog aux = first;

        while (aux != null) {

            if (aux.getData().getId().equals(id)) {

                return aux.getData().getDogName();

            } else {

                aux = aux.getNext();

            }

        }

        return null;

    }

}
