/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Logic;

/**
 *
 * @author Ramfel22
 */
public class NodeSchedule {
    
    private Schedule data;
    
    private NodeSchedule next;
    
    
    public NodeSchedule(Schedule d){
        
        data = d;
        
        next = null;
        
    }
    
    public Schedule getData(){
        
        return data;
        
    }
    
    public void setData(Schedule d){
        
        data = d;
        
    }
    
    public NodeSchedule getNext(){
        
        return next;
        
    }
    
    public void setNext(NodeSchedule n){
        
        next = n;
        
    }
    
}
