/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Logic;

/**
 *
 * @author Ramfel22
 */
public class ListSchedule {

    NodeSchedule first;

    public ListSchedule() {

        first = null;

    }

    public NodeSchedule getFirst() {

        return first;

    }

    public boolean addNode(Schedule sc) {

        NodeSchedule nn = new NodeSchedule(sc);

        if (first == null) {

            first = nn;

            return true;

        } else {

            NodeSchedule aux = first;

            while (aux.getNext() != null) {

                aux = aux.getNext();

            }

            aux.setNext(nn);

            return true;

        }

    }

    public Schedule searchNode(String DogName) {

        NodeSchedule aux = first;

        while (aux != null) {

            if (aux.getData().getDogName().equals(DogName)) {

                return aux.getData();

            } else {

                aux = aux.getNext();

            }

        }

        return null;

    }
    
    public boolean deleteNode(String DogName) {

        if (first == null) {

            return false;

        } else if (first.getData().getDogName().equals(DogName)) {

            first = first.getNext();
            
            return true;

        } else {

            NodeSchedule aux = first;

            while (aux.getNext() != null) {

                if (aux.getNext().getData().getDogName().equals(DogName)) {

                    aux.setNext(aux.getNext().getNext());
                    
                    return true;

                } else {

                    aux = aux.getNext();

                }

            }

        }

        return false;

    }
    
     public boolean modifyNode(Schedule s) {

        NodeSchedule aux = first;

        while (aux != null) {

            if (aux.getData().getDogName().equals(s.getDogName())) {

                aux.setData(s);

                return true;

            } else {

                aux = aux.getNext();

            }

        }

        return false;

    }
     
     
}
