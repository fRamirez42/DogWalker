/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Logic;

/**
 *
 * @author Ramfel22
 */
public class Dog {
    
    private String OwnersName;
    
    private String Phone;
    
    private String Location;
    
    private double payment;
    
    private String Id;
    
    private String DogName;
    
    private String Breed;
    
    private int Age;
    
    private double weight;
    
    private int times;
    
    private String vet;
    
    public Dog (String On, String ph, String l, double p, String i, String Dn, String b, int a, double w,int x, String v){
        
        OwnersName = On;
        
        Phone = ph;
        
        Location = l;
        
        payment = p;
        
        Id = i;
        
        DogName = Dn;
        
        Breed = b;
        
        Age = a;
        
        weight = w;
        
        times = x;
        
        vet = v;
        
    }
    
    public String getOwnersName(){
        
        return OwnersName;
        
    }
    
    public void setOwnersName(String On){
        
        OwnersName = On;
        
    }
    
    public String getPhone(){
        
        return Phone;
        
    }
    
    public void setPhone(String ph){
        
        Phone = ph;
        
    }
    
    public String getLocation(){
        
        return Location;
        
    }
    
    public void setLocation(String l){
        
        Location = l;
        
    }
    
    public double getPayment(){
        
        return payment;
        
    }
    
    public void setPayment(double p){
        
        payment = p;
        
    }
    
    public String getId(){
        
        return Id;
        
    }
    
    public void setId(String i){
        
        Id = i;
        
    }
    
    public String getDogName(){
        
        return DogName;
        
    }
    
    public void setDogName(String Dn){
        
        DogName = Dn;
        
    }
    
     public String getBreed(){
        
        return Breed;
        
    }
    
    public void setBreed(String b){
        
        Breed = b;
        
    }
    
    public int getAge(){
        
        return Age;
        
    }
    
    public void setAge(int a){
        
        Age = a;
        
    }
    
    public double getWeight(){
        
        return weight;
        
    }
    
    public void setWeight(double w){
        
        weight = w;
        
    }
    
    public int getTimes(){
        
        return times;
        
    }
    
    public void setTimes(int x){
        
        times = x;
        
    }
    
    public String getVet(){
        
        return vet;
        
    }
    
    public void setVet(String v){
        
        vet = v;
        
    }
    
}
