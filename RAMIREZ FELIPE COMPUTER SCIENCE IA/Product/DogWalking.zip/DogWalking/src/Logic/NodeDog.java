/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Logic;

/**
 *
 * @author Ramfel22
 */
public class NodeDog {
    
    private Dog dog;
    
    private NodeDog next;
    
    
    public NodeDog(Dog d){
        
        dog = d;
        
        next = null;
        
    }
    
    public Dog getData(){
        
        return dog;
        
    }
    
    public void setData(Dog d){
        
        dog = d;
        
    }
    
    public NodeDog getNext(){
        
        return next;
        
    }
    
    public void setNext(NodeDog n){
        
        next = n;
        
    }
}
