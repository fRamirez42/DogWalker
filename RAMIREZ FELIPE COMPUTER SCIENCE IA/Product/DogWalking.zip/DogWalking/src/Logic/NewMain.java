/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Logic;

/**
 *
 * @author Ramfel22
 */
public class NewMain {

    /**
     * @param args the command line arguments
     */
    public static ListDog dogsList = new ListDog();
    
    public static ListSchedule scheduleList = new ListSchedule();
    
    public static void main(String[] args) {
        
        
        
    }
    
    
}
